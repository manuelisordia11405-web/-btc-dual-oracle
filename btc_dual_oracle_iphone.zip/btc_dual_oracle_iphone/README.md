# BTC Dual Oracle Mobile — iPhone edition

A mobile-first static website for educational Bitcoin 15-minute direction analysis and manual Kalshi target comparison. This is not the original ZERO indicator and does not place trades.

## Publish using only an iPhone

1. Create or sign into GitHub in Safari.
2. Create a **public** repository named `btc-dual-oracle` (GitHub Pages free tier generally requires a public repository).
3. In the repository, choose **Add file → Upload files** (request Desktop Website in Safari if necessary). Upload `index.html` from the extracted ZIP, and commit.
4. Open **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, `main`, `/ (root)`, then Save.
5. After deployment, open `https://YOUR-USERNAME.github.io/btc-dual-oracle/` in Safari. Use **Share → Add to Home Screen**.

No server, Python, or paid hosting required. GitHub UI wording can change.

## Limitations

- Tries public Kraken BTC/USD 1-minute OHLC, then Coinbase BTC/USD candles, then Binance.US BTC/USD candles. Browser CORS, rate limits, geo-restrictions, or downtime may prevent loading. Sources are not interchangeable with Kalshi's settlement reference.
- A 4-indicator agreement percentage is **not** a win probability, forecast confidence calibration, or financial advice.
- The countdown tracks standard UTC quarter-hour boundaries, **not** a verified Kalshi contract expiry.
- Kalshi target is manually entered and saved in browser local storage. No Kalshi market data, prices, or trades are fetched.
- App refreshes approximately every 30 seconds while open. iOS may pause it in the background.
