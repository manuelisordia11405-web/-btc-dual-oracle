BTC Dual Oracle V2.0 - iPhone GitHub Pages

1. Save index.html to Files on your iPhone.
2. Open https://github.com/manuelisordia11405-web/-btc-dual-oracle in Safari.
3. Open the existing index.html, tap the edit pencil (you may need the ... menu), select all the old code and replace with new code; OR use the repository Add file > Upload files and select the new index.html, confirming replacement/commit.
4. Commit directly to the main branch.
5. Wait a minute or two for GitHub Pages to publish and refresh your existing site.
6. In Safari: Share > Add to Home Screen.

Features: 1-minute candles, 5 directional votes, RSI, MACD, EMAs, Bollinger, volume, chart, manual Kalshi inputs, local signal history, news and official economic calendar links.

IMPORTANT: Research tool only. No guaranteed accuracy. Market target and YES/NO prices are manual, not live Kalshi quotes. Live chart/news depend on third-party services; no automatic trading. Historical scoring may remain pending if the app is closed and past candles become unavailable.
